/**
 * dashboard.js — Clone2GHL Full Dashboard
 */

// ─── State ────────────────────────────────────────────────────────────────────
let funnelLibrary = [];
let myFunnels = [];
let settings = {};
let currentFunnelId = null;
let videoPollTimer = null;
let lastVideoScriptSuggestion = null;

// ─── Init ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await loadAll();
  setupNavigation();
  setupFunnelsTab();
  setupLibraryTab();
  setupAiToolsTab();
  setupVideoGenTab();
  setupAdIntelTab();
  setupLogoTab();
  setupAccountTab();
  setupSettingsTab();
  setupModal();
  setupDevModeToggle();

  // Handle hash navigation (popup links to #library, #settings etc.)
  const hash = window.location.hash.replace('#', '');
  if (hash) switchTab(hash);
});

async function loadAll() {
  // Load settings
  const sr = await sendMsg({ action: 'GET_SETTINGS' });
  settings = sr?.settings || {};

  // If a backend session exists, refresh usage early so plan/credits are accurate.
  if (settings.backendEnabled && settings.backendToken) {
    const usageResult = await sendMsg({ action: 'BACKEND_GET_USAGE' });
    if (usageResult?.success) {
      const refreshed = await sendMsg({ action: 'GET_SETTINGS' });
      settings = refreshed?.settings || settings;
    }
  }

  // Load my funnels
  const fr = await sendMsg({ action: 'GET_FUNNELS' });
  myFunnels = fr?.funnels || [];

  // Load funnel library
  try {
    const resp = await fetch(chrome.runtime.getURL('data/funnelLibrary.json'));
    funnelLibrary = await resp.json();
  } catch { funnelLibrary = []; }

  updateSidebarPlanInfo();
}

// ─── Messaging ────────────────────────────────────────────────────────────────
function sendMsg(message) {
  return chrome.runtime.sendMessage(message).catch((err) => ({
    success: false,
    error: err?.message || 'Runtime connection error',
  }));
}

// ─── Navigation ───────────────────────────────────────────────────────────────
function setupNavigation() {
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });
}

function switchTab(tabName) {
  const tabMap = {
    funnels: 'funnels', library: 'library', 'ai-tools': 'ai-tools',
    'video-gen': 'video-gen', 'ad-intel': 'ad-intel', 'logo-gen': 'logo-gen',
    settings: 'settings', account: 'account',
    pricing: 'settings',
  };
  const tab = tabMap[tabName] || tabName;

  document.querySelectorAll('.nav-item').forEach(b => {
    b.classList.toggle('active', b.dataset.tab === tab);
  });
  document.querySelectorAll('.tab-content').forEach(c => {
    c.classList.toggle('active', c.id === `tab-${tab}`);
  });

  if (tab === 'settings' && tabName === 'pricing') {
    setTimeout(() => {
      document.getElementById('tab-pricing-card')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }

  if (tab === 'video-gen') {
    loadVideoJobs(false);
  }

  if (tab === 'account' && settings.backendToken) {
    loadBackendAccountData();
  }
}

// ─── Sidebar Plan Info ────────────────────────────────────────────────────────
function updateSidebarPlanInfo() {
  const nameEl = document.querySelector('.plan-name');
  const credEl = document.getElementById('sidebar-credits');
  if (!settings) return;

  if (nameEl) nameEl.textContent = `${settings.plan?.charAt(0).toUpperCase() + settings.plan?.slice(1) || 'Free'} Plan`;
  if (credEl) {
    if (settings.devMode) {
      credEl.textContent = 'Dev Mode — Unlimited';
    } else if (settings.plan === 'free') {
      credEl.textContent = `${settings.credits ?? 6} clone${settings.credits !== 1 ? 's' : ''} remaining`;
    } else if (settings.plan === 'starter') {
      credEl.textContent = `${settings.credits ?? 24} clone${settings.credits !== 1 ? 's' : ''} remaining`;
    } else if (settings.plan === 'pro') {
      credEl.textContent = '300 clones/month';
    } else {
      credEl.textContent = 'Unlimited clones';
    }
  }

  // Dev Mode badge + toggle sync
  const devBadge = document.getElementById('devmode-badge');
  const devToggle = document.getElementById('sidebar-devmode-toggle');
  if (devBadge) devBadge.style.display = settings.devMode ? 'block' : 'none';
  if (devToggle) devToggle.checked = Boolean(settings.devMode);

  document.getElementById('btn-upgrade-sidebar')?.addEventListener('click', () => switchTab('settings'));
}

function setupDevModeToggle() {
  const toggle = document.getElementById('sidebar-devmode-toggle');
  if (!toggle) return;
  toggle.addEventListener('change', async () => {
    const result = await sendMsg({ action: 'SAVE_SETTINGS', data: { devMode: toggle.checked } });
    settings = result?.settings || settings;
    settings.devMode = toggle.checked;
    updateSidebarPlanInfo();
  });
}

// ─── My Funnels Tab ───────────────────────────────────────────────────────────
function setupFunnelsTab() {
  renderFunnels();

  document.getElementById('btn-clone-new')?.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      await chrome.tabs.sendMessage(tab.id, { action: 'SHOW_CLONE_PANEL' }).catch(() => {});
    }
  });

  document.getElementById('btn-url-clone')?.addEventListener('click', cloneFromUrl);
  document.getElementById('url-input')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') cloneFromUrl();
  });
}

function renderFunnels() {
  const grid = document.getElementById('funnels-grid');
  const empty = document.getElementById('funnels-empty');
  if (!grid || !empty) return;

  if (myFunnels.length === 0) {
    grid.style.display = 'none';
    empty.style.display = 'block';
    return;
  }

  empty.style.display = 'none';
  grid.style.display = 'grid';
  grid.innerHTML = '';

  myFunnels.forEach(funnel => {
    grid.appendChild(buildFunnelCard(funnel));
  });
}

function buildFunnelCard(funnel) {
  const card = document.createElement('div');
  card.className = 'funnel-card';

  const score = funnel.analysis?.score || 0;
  const grade = funnel.analysis?.grade || '—';
  const statusLabel = { draft: 'Draft', optimized: 'AI Optimized', exported: 'Exported to GHL' }[funnel.status] || 'Draft';
  const nicheEmoji = nicheToEmoji(funnel.niche);
  const date = funnel.createdAt ? new Date(funnel.createdAt).toLocaleDateString() : '';

  card.innerHTML = `
    <div class="funnel-card-preview">
      ${nicheEmoji}
      <span class="funnel-status-badge status-${funnel.status || 'draft'}">${statusLabel}</span>
    </div>
    <div class="funnel-card-body">
      <div class="funnel-card-title">${escHtml(funnel.name || 'Untitled Funnel')}</div>
      <div class="funnel-card-meta">
        <span class="funnel-tag">${funnel.niche || 'general'}</span>
        <span>${date}</span>
      </div>
      ${score > 0 ? `
      <div class="score-bar">
        <div class="score-bar-track"><div class="score-bar-fill" style="width:${score}%"></div></div>
        <span class="score-label">Score: ${score}/100 (${grade})</span>
      </div>` : ''}
      <div class="funnel-card-actions">
        <button class="btn-primary btn-view" data-id="${funnel.id}">View</button>
        <button class="btn-primary btn-push" data-id="${funnel.id}">→ GHL</button>
        <button class="btn-danger btn-delete" data-id="${funnel.id}">🗑</button>
      </div>
    </div>
  `;

  card.querySelector('.btn-view').addEventListener('click', (e) => {
    e.stopPropagation();
    openFunnelModal(funnel);
  });

  card.querySelector('.btn-push').addEventListener('click', (e) => {
    e.stopPropagation();
    pushFunnelToGHL(funnel.id, e.target);
  });

  card.querySelector('.btn-delete').addEventListener('click', async (e) => {
    e.stopPropagation();
    if (confirm(`Delete "${funnel.name}"?`)) {
      await sendMsg({ action: 'DELETE_FUNNEL', id: funnel.id });
      myFunnels = myFunnels.filter(f => f.id !== funnel.id);
      renderFunnels();
      updateFunnelSelects();
    }
  });

  card.addEventListener('click', () => openFunnelModal(funnel));

  return card;
}

async function cloneFromUrl() {
  const url = document.getElementById('url-input')?.value?.trim();
  if (!url) return;

  // Open URL in new tab and instruct user
  const tab = await chrome.tabs.create({ url, active: true });
  setTimeout(() => {
    chrome.tabs.sendMessage(tab.id, { action: 'SHOW_CLONE_PANEL' }).catch(() => {});
  }, 2000);
}

async function pushFunnelToGHL(funnelId, btnEl) {
  if (!settings.ghlApiKey || !settings.ghlLocationId) {
    alert('Please configure your GHL API key and Location ID in Settings first.');
    switchTab('settings');
    return;
  }

  const originalText = btnEl.textContent;
  btnEl.innerHTML = '<span class="spinner"></span> Exporting…';
  btnEl.disabled = true;

  const result = await sendMsg({ action: 'PUSH_TO_GHL', data: { funnelId, useOptimized: true } });

  btnEl.disabled = false;

  if (!result?.success) {
    alert(buildPushErrorMessage(result?.error || 'Unknown error'));
    btnEl.textContent = originalText;
    return;
  }

  if (result.success === 'html_only' || result.success === 'partial') {
    btnEl.textContent = '⚠ Check GHL';
    const msg = (result.warning || 'Partial export.') +
      '\n\nClick OK to open the GHL builder. You can also Download HTML from "View" to paste it in manually.';
    if (confirm(msg)) chrome.tabs.create({ url: result.ghlBuilderUrl });
  } else {
    btnEl.textContent = '✓ Exported!';
    const label = result.funnelName ? ` to funnel "${result.funnelName}"` : '';
    if (confirm(`Page exported${label}! Open in GHL builder?`)) {
      chrome.tabs.create({ url: result.ghlBuilderUrl });
    }
  }

  const fr = await sendMsg({ action: 'GET_FUNNELS' });
  myFunnels = fr?.funnels || [];
  renderFunnels();
}

function buildPushErrorMessage(rawError) {
  const err = String(rawError || '').toLowerCase();
  let advice = 'Try again in a few seconds.';

  if (err.includes('location id')) {
    advice = 'Open Settings and verify your GHL Location ID exactly matches your GHL account.';
  } else if (err.includes('api key') || err.includes('401') || err.includes('invalid')) {
    advice = 'Re-check your GHL API key in Settings and click Test Connection before exporting.';
  } else if (err.includes('timed out') || err.includes('network')) {
    advice = 'Check your internet connection, then retry export. If this continues, use Download HTML as fallback.';
  } else if (err.includes('no funnels found')) {
    advice = 'Create at least one funnel in GoHighLevel first, then retry export.';
  } else if (err.includes('quota') || err.includes('storage limit')) {
    advice = 'Delete older saved funnels in My Funnels to free storage, then retry.';
  }

  return `Export failed:\n${rawError}\n\nNext step:\n${advice}`;
}

// ─── Funnel Modal ─────────────────────────────────────────────────────────────
function setupModal() {
  document.getElementById('modal-close')?.addEventListener('click', closeModal);
  document.getElementById('funnel-modal')?.addEventListener('click', (e) => {
    if (e.target.id === 'funnel-modal') closeModal();
  });
}

function openFunnelModal(funnel) {
  currentFunnelId = funnel.id;
  const modal = document.getElementById('funnel-modal');
  const title = document.getElementById('modal-funnel-title');
  const body = document.getElementById('modal-body');

  title.textContent = funnel.name || 'Funnel Details';
  body.innerHTML = buildModalContent(funnel);

  modal.style.display = 'flex';

  // Wire up modal buttons
  body.querySelector('#modal-btn-push')?.addEventListener('click', async () => {
    await pushFunnelToGHL(funnel.id, body.querySelector('#modal-btn-push'));
  });

  body.querySelector('#modal-btn-optimize')?.addEventListener('click', async () => {
    const btn = body.querySelector('#modal-btn-optimize');
    btn.innerHTML = '<span class="spinner"></span> Optimizing…';
    btn.disabled = true;
    const niche = funnel.niche || 'general';
    const result = await sendMsg({ action: 'OPTIMIZE_FUNNEL', data: { funnelId: funnel.id, niche } });
    if (result?.success) {
      btn.textContent = '✓ Optimized!';
      const fr = await sendMsg({ action: 'GET_FUNNELS' });
      myFunnels = fr?.funnels || [];
    } else {
      alert(result?.error || 'Optimization failed');
      btn.textContent = '🤖 AI Optimize';
      btn.disabled = false;
    }
  });

  body.querySelector('#modal-btn-preview')?.addEventListener('click', () => {
    const html = funnel.optimizedHtml || funnel.html;
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  });

  body.querySelector('#modal-btn-download')?.addEventListener('click', () => {
    const html = funnel.optimizedHtml || funnel.html;
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(funnel.name || 'funnel').replace(/\s+/g, '-')}.html`;
    a.click();
  });
}

function buildModalContent(funnel) {
  const a = funnel.analysis;
  const score = a?.score || 0;
  const grade = a?.grade || '—';

  let analysisHtml = '';
  if (a) {
    const allInsights = [
      ...(a.ctaInsights || []),
      ...(a.formInsights || []),
      ...(a.trustScore?.insights || a.trustSignals?.map(t => ({ type: 'good', text: t.label })) || []),
    ].slice(0, 8);

    const insightItems = allInsights.map(i => `
      <div class="insight-item ${i.type || 'neutral'}">
        <span class="insight-dot">${i.type === 'good' ? '✓' : i.type === 'warning' ? '⚠' : i.type === 'tip' ? '💡' : '•'}</span>
        <span>${escHtml(i.text)}</span>
      </div>`).join('');

    const recItems = (a.recommendations || []).slice(0, 4).map(r => `
      <div class="rec-item">
        <span class="rec-priority ${r.priority}">${r.priority}</span>
        <span>${escHtml(r.action)}</span>
      </div>`).join('');

    const headlineTypes = (a.headlineTypes || []).map(h => `<span class="funnel-tag">${h.type}</span>`).join(' ');

    analysisHtml = `
      <div class="section-label">Funnel Intelligence</div>
      <div class="funnel-detail-grid">
        <div class="detail-stat">
          <div class="detail-stat-label">Conversion Score</div>
          <div class="detail-stat-value">${score}/100 <span style="font-size:16px">${grade}</span></div>
          <div class="detail-stat-sub">${a.summary || ''}</div>
        </div>
        <div class="detail-stat">
          <div class="detail-stat-label">Niche Detected</div>
          <div class="detail-stat-value">${a.detectedNiche || 'general'}</div>
          <div class="detail-stat-sub">${(a.testimonialCount || 0)} testimonials · ${(a.sectionCount || 0)} sections</div>
        </div>
      </div>
      ${headlineTypes ? `<div style="margin-bottom:8px;display:flex;gap:6px;flex-wrap:wrap;">${headlineTypes}</div>` : ''}
      ${insightItems ? `<div class="insight-list">${insightItems}</div>` : ''}
      ${recItems ? `<div class="section-label">Recommendations</div><div class="rec-list">${recItems}</div>` : ''}
      ${a.urgencyElements?.length ? `
        <div class="section-label">Urgency Elements</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">${a.urgencyElements.map(u => `<span class="funnel-tag">${escHtml(u)}</span>`).join('')}</div>
      ` : ''}
    `;

    if (funnel.aiReport) {
      analysisHtml += `<div class="section-label">AI Analysis</div><div class="intel-report">${escHtml(funnel.aiReport)}</div>`;
    }
  }

  return `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
      <div style="font-size:2rem;">${nicheToEmoji(funnel.niche)}</div>
      <div>
        <div style="font-size:13px;color:var(--text4);">${funnel.sourceUrl || 'Library template'}</div>
        <div style="font-size:12px;color:var(--text4);margin-top:2px;">
          ${funnel.niche || 'general'} · ${funnel.status || 'draft'}
          ${funnel.exportedAt ? ` · Exported ${new Date(funnel.exportedAt).toLocaleDateString()}` : ''}
        </div>
      </div>
    </div>

    ${funnel.status === 'optimized' ? `<div class="tool-status success">✓ AI Optimized copy available — exporting will use the optimized version.</div>` : ''}
    ${funnel.ghlFunnelId ? `<div class="tool-status success">✓ Exported to GHL — Funnel ID: ${funnel.ghlFunnelId}</div>` : ''}

    ${analysisHtml}

    <div class="modal-actions">
      <button class="btn-primary" id="modal-btn-push">→ Push to GHL</button>
      <button class="btn-secondary" id="modal-btn-optimize">🤖 AI Optimize</button>
      <button class="btn-secondary" id="modal-btn-preview">👁 Preview HTML</button>
      <button class="btn-secondary" id="modal-btn-download">⬇ Download HTML</button>
    </div>
  `;
}

function closeModal() {
  document.getElementById('funnel-modal').style.display = 'none';
  currentFunnelId = null;
}

// ─── Library Tab ──────────────────────────────────────────────────────────────
function setupLibraryTab() {
  renderLibrary();
  document.getElementById('library-niche-filter')?.addEventListener('change', renderLibrary);
  document.getElementById('library-type-filter')?.addEventListener('change', renderLibrary);
  document.getElementById('library-perf-filter')?.addEventListener('change', renderLibrary);
}

function renderLibrary() {
  const grid = document.getElementById('library-grid');
  if (!grid) return;

  const nicheFilter = document.getElementById('library-niche-filter')?.value || '';
  const typeFilter = document.getElementById('library-type-filter')?.value || '';
  const perfFilter = document.getElementById('library-perf-filter')?.value || '';

  let items = funnelLibrary;
  if (nicheFilter) items = items.filter(f => f.niche === nicheFilter);
  if (typeFilter) items = items.filter(f => f.type === typeFilter);
  if (perfFilter) items = items.filter(f => f.performance === perfFilter);

  grid.innerHTML = '';
  if (items.length === 0) {
    grid.innerHTML = '<p style="color:var(--text4);padding:20px;">No funnels match the selected filters.</p>';
    return;
  }

  items.forEach(tpl => {
    const card = document.createElement('div');
    card.className = 'library-card';

    const emoji = nicheToEmoji(tpl.niche);
    const perfClass = { high_converting: 'high', trending: 'trending' }[tpl.performance] || 'high';
    const perfLabel = { high_converting: '🔥 High Converting', trending: '📈 Trending' }[tpl.performance] || '';

    card.innerHTML = `
      <div class="library-card-preview">
        ${emoji}
        <span class="perf-badge perf-${perfClass}">${perfLabel}</span>
      </div>
      <div class="library-card-body">
        <div class="library-card-title">${escHtml(tpl.name)}</div>
        <div class="library-card-desc">${escHtml(tpl.description)}</div>
        <div class="library-card-stats">
          <span class="stat-pill green">✓ ${tpl.stats?.conversionRate || 'N/A'} CVR</span>
          <span class="stat-pill orange">⚡ ${tpl.stats?.avgLeads || 'N/A'}</span>
        </div>
        <div style="display:flex;gap:8px;">
          <button class="btn-primary" style="flex:1;justify-content:center;" data-id="${tpl.id}">Clone + Customize</button>
          <button class="btn-secondary btn-preview-tpl" data-id="${tpl.id}">👁</button>
        </div>
      </div>
    `;

    card.querySelector('.btn-primary').addEventListener('click', () => cloneFromLibrary(tpl));
    card.querySelector('.btn-preview-tpl').addEventListener('click', () => previewTemplate(tpl));

    grid.appendChild(card);
  });
}

async function cloneFromLibrary(tpl) {
  // Save the library template as a funnel in the user's "My Funnels"
  const funnel = {
    id: `lib_${tpl.id}_${Date.now()}`,
    name: tpl.name,
    sourceUrl: 'Library Template',
    niche: tpl.niche,
    status: 'draft',
    html: tpl.html,
    optimizedHtml: null,
    analysis: null,
    meta: { title: tpl.name, url: '', capturedAt: new Date().toISOString() },
  };

  await sendMsg({ action: 'SAVE_FUNNEL', data: funnel });
  const fr = await sendMsg({ action: 'GET_FUNNELS' });
  myFunnels = fr?.funnels || [];
  renderFunnels();
  updateFunnelSelects();
  switchTab('funnels');
}

function previewTemplate(tpl) {
  const blob = new Blob([tpl.html], { type: 'text/html' });
  window.open(URL.createObjectURL(blob), '_blank');
}

// ─── AI Tools Tab ─────────────────────────────────────────────────────────────
function setupAiToolsTab() {
  updateFunnelSelects();

  // AI Optimize
  document.getElementById('btn-ai-optimize')?.addEventListener('click', async () => {
    const funnelId = document.getElementById('ai-opt-funnel-select').value;
    const niche = document.getElementById('ai-opt-niche').value;
    const businessName = document.getElementById('ai-opt-business').value.trim();
    const statusEl = document.getElementById('ai-opt-status');

    if (!funnelId) return setToolStatus(statusEl, 'Please select a funnel first.', 'error');
    if (!settings.backendToken) return setToolStatus(statusEl, 'Please sign in to your Clone2GHL account to use AI features.', 'error');

    setToolStatus(statusEl, '<span class="spinner"></span> Optimizing copy with GPT-4o…', 'loading');
    document.getElementById('btn-ai-optimize').disabled = true;

    const result = await sendMsg({
      action: 'OPTIMIZE_FUNNEL',
      data: { funnelId, niche: niche || undefined, businessName: businessName || undefined },
    });

    document.getElementById('btn-ai-optimize').disabled = false;

    if (result?.success) {
      setToolStatus(statusEl, '✓ Copy optimized! View in My Funnels.', 'success');
      const fr = await sendMsg({ action: 'GET_FUNNELS' });
      myFunnels = fr?.funnels || [];
      renderFunnels();
    } else {
      setToolStatus(statusEl, `Error: ${result?.error || 'Unknown error'}`, 'error');
    }
  });

  // Funnel Intelligence
  document.getElementById('btn-intel-analyze')?.addEventListener('click', async () => {
    const funnelId = document.getElementById('intel-funnel-select').value;
    const statusEl = document.getElementById('intel-status');
    const reportEl = document.getElementById('intel-report');

    if (!funnelId) return setToolStatus(statusEl, 'Please select a funnel.', 'error');

    const funnel = myFunnels.find(f => f.id === funnelId);
    if (!funnel) return setToolStatus(statusEl, 'Funnel not found.', 'error');

    if (funnel.analysis) {
      reportEl.textContent = buildTextReport(funnel.analysis);
      reportEl.style.display = 'block';
      setToolStatus(statusEl, `Score: ${funnel.analysis.score}/100 (${funnel.analysis.grade}) — ${funnel.analysis.detectedNiche}`, 'success');
      return;
    }

    setToolStatus(statusEl, '<span class="spinner"></span> Analyzing…', 'loading');
    document.getElementById('btn-intel-analyze').disabled = true;

    // Re-analyze from the funnel HTML structure (simplified, structure not stored separately)
    setToolStatus(statusEl, 'Analysis data not available for this funnel. Clone a fresh page for full intelligence.', 'info');
    document.getElementById('btn-intel-analyze').disabled = false;
  });

  // Headline Generator
  document.getElementById('btn-gen-headlines')?.addEventListener('click', async () => {
    const niche = document.getElementById('headline-niche').value;
    const offer = document.getElementById('headline-offer').value.trim();
    const listEl = document.getElementById('headlines-list');

    if (!settings.backendToken) {
      alert('Please sign in to your Clone2GHL account to use AI features.');
      return;
    }

    document.getElementById('btn-gen-headlines').innerHTML = '<span class="spinner"></span> Generating…';
    document.getElementById('btn-gen-headlines').disabled = true;

    const result = await sendMsg({ action: 'GENERATE_HEADLINES', niche, offer: offer || `${niche} service` });

    document.getElementById('btn-gen-headlines').textContent = '✨ Generate Headlines';
    document.getElementById('btn-gen-headlines').disabled = false;

    if (result?.success && result.headlines?.length) {
      listEl.style.display = 'flex';
      listEl.innerHTML = result.headlines.map(h => `
        <div class="headline-item">
          <span>${escHtml(h)}</span>
          <button class="btn-copy-headline" title="Copy" onclick="copyText(this, '${h.replace(/'/g, "\\'")}')">📋</button>
        </div>
      `).join('');
    } else {
      alert(result?.error || 'Failed to generate headlines');
    }
  });

  // AI Video Generator
  document.getElementById('btn-ai-video-generate')?.addEventListener('click', async () => {
    const prompt = document.getElementById('ai-video-prompt')?.value?.trim() || '';
    const durationSec = Number(document.getElementById('ai-video-duration')?.value || 16);
    const size = document.getElementById('ai-video-size')?.value || '1920x1080';
    const statusEl = document.getElementById('ai-video-status');
    const btn = document.getElementById('btn-ai-video-generate');

    if (!prompt) {
      setToolStatus(statusEl, 'Please enter a video prompt first.', 'error');
      return;
    }

    if (!requireBackendAuth(statusEl)) return;

    const providerStatus = await sendMsg({ action: 'BACKEND_VIDEO_PROVIDER_STATUS' });
    if (!providerStatus?.success || !providerStatus?.videoGeneration?.available) {
      setToolStatus(statusEl, 'OpenAI video generation is not configured on the backend. Add OPENAI_API_KEY first.', 'error');
      return;
    }

    const originalHtml = btn?.innerHTML;
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Generating…';
    }

    setToolStatus(statusEl, `<span class="spinner"></span> Queuing Sora ${providerStatus.videoGeneration?.model || 'video'}…`, 'loading');

    const result = await sendMsg({
      action: 'BACKEND_VIDEO_GENERATE',
      prompt,
      script: prompt,
      provider: 'openai',
      template: 'openai_prompt',
      seconds: durationSec,
      size,
      model: providerStatus.videoGeneration?.model || 'sora-2-pro',
    });

    if (btn) {
      btn.disabled = false;
      btn.innerHTML = originalHtml || '🎬 Generate Video';
    }

    if (!result?.success || !result.job?.id) {
      setToolStatus(statusEl, `Error: ${result?.error || 'Unable to create video job'}`, 'error');
      return;
    }

    const model = result.job.videoModel || providerStatus.videoGeneration?.model || 'sora-2-pro';
    setToolStatus(statusEl, `✓ Job queued: ${result.job.id} using ${model}. Track it in Video Generation.`, 'success');
    await loadVideoJobs(false);
  });
}

function updateFunnelSelects() {
  const selects = ['ai-opt-funnel-select', 'intel-funnel-select'];
  selects.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = '<option value="">Select a funnel…</option>' +
      myFunnels.map(f => `<option value="${f.id}">${escHtml(f.name || 'Untitled')}</option>`).join('');
  });

  updateVideoFunnelSelect();
}

function buildTextReport(a) {
  const lines = [
    `FUNNEL INTELLIGENCE REPORT`,
    `Score: ${a.score}/100 (${a.grade}) | Niche: ${a.detectedNiche}`,
    '',
    a.summary,
    '',
    'HEADLINE TYPES:',
    ...(a.headlineTypes || []).map(h => `  • ${h.type}: "${h.text}"`),
    '',
    'URGENCY ELEMENTS:',
    ...(a.urgencyElements?.length ? a.urgencyElements.map(u => `  • ${u}`) : ['  None detected']),
    '',
    'TRUST SIGNALS:',
    ...(a.trustSignals?.length ? a.trustSignals.map(t => `  ✓ ${t.label}`) : ['  None detected']),
    '',
    'RECOMMENDATIONS:',
    ...(a.recommendations || []).map(r => `  [${r.priority.toUpperCase()}] ${r.action}`),
  ];
  return lines.join('\n');
}

// ─── Video Generation Tab ────────────────────────────────────────────────────
function setupVideoGenTab() {
  updateVideoFunnelSelect();

  document.getElementById('video-provider')?.addEventListener('change', async () => {
    updateVideoDemoBanner();
    await refreshVideoProviderHints();
  });

  document.getElementById('btn-video-apply-script')?.addEventListener('click', () => {
    if (!lastVideoScriptSuggestion?.script) return;
    const scriptEl = document.getElementById('video-script');
    if (scriptEl) scriptEl.value = lastVideoScriptSuggestion.script;
    setToolStatus(document.getElementById('video-status'), '✓ Script inserted. You can now generate the video.', 'success');
  });

  document.getElementById('btn-video-script')?.addEventListener('click', async () => {
    const statusEl = document.getElementById('video-status');
    if (!requireBackendAuth(statusEl)) return;

    const niche = document.getElementById('video-script-niche')?.value?.trim() || 'general';
    const offer = document.getElementById('video-script-offer')?.value?.trim() || '';
    const tone = document.getElementById('video-script-tone')?.value || 'professional';
    const durationSec = Number(document.getElementById('video-script-duration')?.value || 30);
    const cta = document.getElementById('video-script-cta')?.value?.trim() || 'Book now';
    const btn = document.getElementById('btn-video-script');

    const originalHtml = btn?.innerHTML;
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Generating…';
    }

    setToolStatus(statusEl, '<span class="spinner"></span> Generating script…', 'loading');
    const result = await sendMsg({
      action: 'BACKEND_VIDEO_SCRIPT',
      niche,
      offer,
      tone,
      durationSec,
      cta,
    });

    if (btn) {
      btn.disabled = false;
      btn.innerHTML = originalHtml || '✨ Generate Script';
    }

    if (!result?.success || !result.script) {
      setToolStatus(statusEl, `Error: ${result?.error || 'Unable to generate script'}`, 'error');
      return;
    }

    lastVideoScriptSuggestion = {
      script: result.script,
      hook: result.hook || '',
      ctaLine: result.ctaLine || '',
      sceneHints: Array.isArray(result.sceneHints) ? result.sceneHints : [],
      model: result.model || 'model',
    };
    renderVideoScriptPreview(lastVideoScriptSuggestion);
    setToolStatus(statusEl, `✓ Script preview ready (${result.model || 'model'}). Click "Use This Script" to apply.`, 'success');
  });

  document.getElementById('btn-video-refresh')?.addEventListener('click', async () => {
    await loadVideoJobs(true);
  });

  document.getElementById('btn-video-generate')?.addEventListener('click', async () => {
    const statusEl = document.getElementById('video-status');
    if (!requireBackendAuth(statusEl)) return;

    const script = document.getElementById('video-script')?.value?.trim() || '';
    const funnelId = document.getElementById('video-funnel-select')?.value || '';
    const avatar = document.getElementById('video-avatar')?.value || 'default';
    const voice = document.getElementById('video-voice')?.value || 'default';
    const template = document.getElementById('video-template')?.value || 'short_promo';
    const provider = document.getElementById('video-provider')?.value || 'mock';
    const seconds = Number(document.getElementById('video-script-duration')?.value || 30);
    const btn = document.getElementById('btn-video-generate');
    let providerStatus = null;

    if (provider === 'heygen') {
      providerStatus = await sendMsg({ action: 'BACKEND_VIDEO_PROVIDER_STATUS' });
      if (!providerStatus?.success || !providerStatus?.providers?.heygen?.available) {
        setToolStatus(statusEl, 'HeyGen provider is not configured on backend. Add HEYGEN_API_KEY or switch provider to Mock.', 'error');
        return;
      }
    } else if (provider === 'openai') {
      providerStatus = await sendMsg({ action: 'BACKEND_VIDEO_PROVIDER_STATUS' });
      if (!providerStatus?.success || !providerStatus?.videoGeneration?.available) {
        setToolStatus(statusEl, 'OpenAI video generation is not configured on backend. Add OPENAI_API_KEY or switch provider.', 'error');
        return;
      }
    }

    if (!script) {
      setToolStatus(statusEl, provider === 'openai' ? 'Please enter a video prompt first.' : 'Please enter a video script first.', 'error');
      return;
    }

    const originalHtml = btn?.innerHTML;
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Queuing video…';
    }
    setToolStatus(statusEl, '<span class="spinner"></span> Submitting video job…', 'loading');

    const result = await sendMsg({
      action: 'BACKEND_VIDEO_GENERATE',
      script,
      prompt: script,
      funnelId,
      avatar,
      voice,
      template,
      provider,
      seconds,
      model: provider === 'openai' ? (providerStatus?.videoGeneration?.model || 'sora-2-pro') : undefined,
    });

    if (btn) {
      btn.disabled = false;
      btn.innerHTML = originalHtml || '🎬 Generate Video';
    }

    if (!result?.success || !result.job?.id) {
      setToolStatus(statusEl, `Error: ${result?.error || 'Unable to create video job'}`, 'error');
      return;
    }

    const model = result.job.videoModel || (provider === 'openai' ? 'sora-2-pro' : 'provider');
    setToolStatus(statusEl, `✓ Job queued: ${result.job.id}${provider === 'openai' ? ` using ${model}.` : '.'}`, 'success');
    await loadVideoJobs(false);
    startVideoPolling(result.job.id, result.job.provider);
  });

  document.getElementById('btn-video-attach-funnel')?.addEventListener('click', async () => {
    const statusEl = document.getElementById('video-attach-status');
    const funnelId = document.getElementById('video-attach-funnel-select')?.value;
    const wrap = document.getElementById('video-preview-wrap');
    const jobId = wrap?.dataset.currentJobId || '';
    const videoUrl = document.getElementById('video-preview-player')?.src || '';

    if (!funnelId) {
      setToolStatus(statusEl, '⚠ Select a funnel to attach the video to.', 'error');
      return;
    }
    if (!videoUrl) {
      setToolStatus(statusEl, '⚠ No video loaded in player.', 'error');
      return;
    }

    const funnel = myFunnels.find(f => f.id === funnelId);
    if (!funnel) {
      setToolStatus(statusEl, '⚠ Funnel not found.', 'error');
      return;
    }

    setToolStatus(statusEl, '<span class="spinner"></span> Attaching…', 'loading');
    const result = await sendMsg({
      action: 'SAVE_FUNNEL',
      data: { ...funnel, videoUrl, videoJobId: jobId },
    });

    if (!result?.success) {
      setToolStatus(statusEl, `✗ ${result?.error || 'Unable to attach video'}`, 'error');
      return;
    }

    const idx = myFunnels.findIndex(f => f.id === funnelId);
    if (idx >= 0) myFunnels[idx] = { ...myFunnels[idx], videoUrl, videoJobId: jobId };

    setToolStatus(statusEl, `✓ Video attached to "${escHtml(funnel.name || 'funnel')}".`, 'success');
    showSaveToast('Video attached to funnel.');
  });

  updateVideoDemoBanner();
  refreshVideoProviderHints();
  loadVideoJobs(false);
}

function renderVideoScriptPreview(suggestion) {
  const wrap = document.getElementById('video-script-preview');
  const body = document.getElementById('video-script-preview-body');
  const meta = document.getElementById('video-script-preview-meta');
  if (!wrap || !body || !meta) return;

  wrap.style.display = 'block';
  body.textContent = suggestion.script || '';

  const hintLines = [];
  if (suggestion.hook) hintLines.push(`Hook: ${suggestion.hook}`);
  if (suggestion.ctaLine) hintLines.push(`CTA: ${suggestion.ctaLine}`);
  if (suggestion.sceneHints?.length) hintLines.push(`Scenes: ${suggestion.sceneHints.join(' | ')}`);
  hintLines.push(`Model: ${suggestion.model || 'n/a'}`);
  meta.textContent = hintLines.join(' · ');
}

function updateVideoDemoBanner() {
  const provider = document.getElementById('video-provider')?.value || 'mock';
  const banner = document.getElementById('video-demo-banner');
  if (banner) banner.style.display = provider === 'mock' ? 'block' : 'none';
}

async function refreshVideoProviderHints() {
  const provider = document.getElementById('video-provider')?.value || 'mock';
  const badge = document.getElementById('video-provider-status');

  updateVideoDemoBanner();

  if (provider === 'mock') {
    if (badge) {
      setToolStatus(badge, '✅ Mock / Demo Mode — no external API needed. Jobs complete in ~3s.', 'success');
      badge.style.display = 'block';
    }
    return;
  }

  if (!badge) return;
  if (!settings.backendToken) {
    badge.style.display = 'none';
    return;
  }

  const result = await sendMsg({ action: 'BACKEND_VIDEO_PROVIDER_STATUS' });
  if (!result?.success) {
    badge.style.display = 'none';
    return;
  }

  const heygenOk = Boolean(result.providers?.heygen?.available);
  const openaiOk = Boolean(result.videoGeneration?.available);
  const scriptOk = Boolean(result.scriptGeneration?.available);
  if (provider === 'heygen' && !heygenOk) {
    setToolStatus(badge, 'HeyGen is not configured on backend. Add HEYGEN_API_KEY or use Mock provider.', 'error');
    return;
  }

  if (provider === 'openai' && !openaiOk) {
    setToolStatus(badge, 'OpenAI video generation is not configured on backend. Add OPENAI_API_KEY or use Mock provider.', 'error');
    return;
  }

  if (!scriptOk) {
    setToolStatus(badge, 'Script generation is unavailable until OPENAI_API_KEY is configured on backend.', 'info');
    return;
  }

  if (provider === 'openai') {
    setToolStatus(badge, `Provider check OK. Video model: ${result.videoGeneration?.model || 'sora-2-pro'} (${result.videoGeneration?.size || '1920x1080'}, ${result.videoGeneration?.seconds || 16}s).`, 'success');
    return;
  }

  setToolStatus(badge, `Provider check OK. Script model: ${result.scriptGeneration?.model || 'n/a'}.`, 'success');
}

function updateVideoFunnelSelect() {
  const select = document.getElementById('video-funnel-select');
  if (!select) return;

  select.innerHTML = '<option value="">No linked funnel (optional)</option>' +
    myFunnels.map(f => `<option value="${f.id}">${escHtml(f.name || 'Untitled')}</option>`).join('');
}

function renderVideoJobs(jobs) {
  const body = document.getElementById('video-jobs-body');
  if (!body) return;

  if (!jobs.length) {
    body.innerHTML = '<tr><td colspan="5" class="activity-empty">No video jobs yet.</td></tr>';
    return;
  }

  body.innerHTML = jobs.map((job) => {
    const videoUrl = job.previewUrl || job.videoUrl || '';
    return `
    <tr>
      <td>${escHtml(formatActivityTime(job.createdAt))}</td>
      <td style="font-size:11px; word-break:break-all;">${escHtml(job.id)}</td>
      <td>${escHtml((job.status || '-').toUpperCase())} (${Number(job.progress || 0)}%)${job.videoModel ? `<br><span style="font-size:10px; opacity:.7;">${escHtml(job.videoModel)}</span>` : ''}</td>
      <td>${videoUrl
          ? `<button class="btn-secondary btn-video-play" data-url="${escHtml(videoUrl)}" data-job-id="${escHtml(job.id)}" style="font-size:11px; padding:4px 10px;">▶ Play</button>`
          : '-'}</td>
      <td>
        ${job.status === 'queued' || job.status === 'processing'
          ? `<button class="btn-danger btn-video-cancel" data-job-id="${escHtml(job.id)}">Cancel</button>`
          : '-'}
      </td>
    </tr>
  `}).join('');

  body.querySelectorAll('.btn-video-cancel').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const jobId = btn.dataset.jobId;
      const statusEl = document.getElementById('video-status');
      if (!jobId) return;

      btn.disabled = true;
      btn.textContent = 'Cancelling…';

      const result = await sendMsg({ action: 'BACKEND_VIDEO_CANCEL_JOB', jobId });
      if (!result?.success) {
        setToolStatus(statusEl, `Error: ${result?.error || 'Unable to cancel job'}`, 'error');
      } else {
        setToolStatus(statusEl, `✓ Job ${jobId} cancelled.`, 'success');
      }

      await loadVideoJobs(false);
    });
  });

  body.querySelectorAll('.btn-video-play').forEach((btn) => {
    btn.addEventListener('click', () => {
      const url = btn.dataset.url;
      const jobId = btn.dataset.jobId;
      const player = document.getElementById('video-preview-player');
      const wrap = document.getElementById('video-preview-wrap');
      const attachSelect = document.getElementById('video-attach-funnel-select');

      if (!player || !wrap || !url) return;

      player.src = url;
      player.load();
      wrap.style.display = 'block';
      wrap.dataset.currentJobId = jobId || '';
      wrap.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

      if (attachSelect) {
        attachSelect.innerHTML = '<option value="">Attach to funnel…</option>' +
          myFunnels.map(f => `<option value="${f.id}">${escHtml(f.name || 'Untitled')}</option>`).join('');
      }
    });
  });
}

async function loadVideoJobs(showStatus = true) {
  const statusEl = document.getElementById('video-status');
  if (!statusEl) return;
  if (!requireBackendAuth(statusEl)) return;

  if (showStatus) setToolStatus(statusEl, '<span class="spinner"></span> Loading video jobs…', 'loading');
  const result = await sendMsg({ action: 'BACKEND_VIDEO_LIST_JOBS', limit: 20 });
  if (!result?.success) {
    setToolStatus(statusEl, `Error: ${result?.error || 'Unable to load video jobs'}`, 'error');
    return;
  }

  const jobs = result.jobs || [];
  renderVideoJobs(jobs);

  const active = jobs.find(job => job.status === 'queued' || job.status === 'processing');
  if (active) {
    startVideoPolling(active.id, active.provider);
  } else if (videoPollTimer) {
    clearInterval(videoPollTimer);
    videoPollTimer = null;
  }

  if (showStatus) setToolStatus(statusEl, `✓ Loaded ${jobs.length} video job(s).`, 'success');
}

function startVideoPolling(jobId, provider = '') {
  if (!jobId) return;

  if (videoPollTimer) clearInterval(videoPollTimer);
  const intervalMs = provider === 'openai' ? 10000 : 2000;
  videoPollTimer = setInterval(async () => {
    const result = await sendMsg({ action: 'BACKEND_VIDEO_GET_JOB', jobId });
    if (!result?.success || !result.job) return;

    const status = result.job.status;
    await loadVideoJobs(false);

    if (status === 'completed' || status === 'failed' || status === 'cancelled') {
      clearInterval(videoPollTimer);
      videoPollTimer = null;
    }
  }, intervalMs);
}

// ─── Ad Intelligence Tab ──────────────────────────────────────────────────────
function setupAdIntelTab() {
  document.getElementById('btn-ad-search')?.addEventListener('click', () => {
    const query = document.getElementById('ad-search-query').value.trim();
    if (!query) return;
    window.open(`https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=US&q=${encodeURIComponent(query)}&search_type=keyword_unordered`, '_blank');
  });

  document.getElementById('ad-search-query')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') document.getElementById('btn-ad-search').click();
  });

  document.getElementById('btn-fb-ads')?.addEventListener('click', () => {
    const q = document.getElementById('ad-search-query').value.trim() || '';
    window.open(`https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=US${q ? `&q=${encodeURIComponent(q)}` : ''}`, '_blank');
  });

  document.getElementById('btn-google-ads')?.addEventListener('click', () => {
    const q = document.getElementById('ad-search-query').value.trim() || '';
    window.open(`https://adstransparency.google.com/${q ? `?query=${encodeURIComponent(q)}` : ''}`, '_blank');
  });

  document.getElementById('btn-tiktok-ads')?.addEventListener('click', () => {
    window.open('https://ads.tiktok.com/business/creativecenter/inspiration/topads/pc/en', '_blank');
  });
}

// ─── Logo Generator Tab ───────────────────────────────────────────────────────
function setupLogoTab() {
  document.getElementById('btn-gen-logo')?.addEventListener('click', async () => {
    const businessName = document.getElementById('logo-business-name').value.trim();
    const industry = document.getElementById('logo-industry').value.trim();
    const style = document.getElementById('logo-style').value;
    const colors = document.getElementById('logo-colors').value;
    const statusEl = document.getElementById('logo-status');
    const resultCard = document.getElementById('logo-result');

    if (!businessName || !industry) {
      setToolStatus(statusEl, 'Please enter a business name and industry.', 'error');
      return;
    }

    if (!settings.backendToken) {
      setToolStatus(statusEl, 'Please sign in to your Clone2GHL account to use AI features.', 'error');
      return;
    }

    document.getElementById('btn-gen-logo').innerHTML = '<span class="spinner"></span> Generating…';
    document.getElementById('btn-gen-logo').disabled = true;
    setToolStatus(statusEl, '<span class="spinner"></span> Generating logo with DALL-E 3…', 'loading');
    resultCard.style.display = 'none';

    const result = await sendMsg({
      action: 'GENERATE_LOGO',
      data: { businessName, industry, style, colors },
    });

    document.getElementById('btn-gen-logo').textContent = '🎨 Generate Logo';
    document.getElementById('btn-gen-logo').disabled = false;

    if (result?.success && result.url) {
      document.getElementById('logo-preview-img').src = result.url;
      document.getElementById('btn-download-logo').href = result.url;
      document.getElementById('logo-revised-prompt').textContent = result.revisedPrompt || '';
      resultCard.style.display = 'flex';
      setToolStatus(statusEl, '✓ Logo generated! Right-click → Save image, or use the Download button.', 'success');
    } else {
      setToolStatus(statusEl, `Error: ${result?.error || 'Logo generation failed'}`, 'error');
    }
  });
}

// ─── Settings Tab ─────────────────────────────────────────────────────────────
function setupSettingsTab() {
  // Populate fields from saved settings
  loadSettingsFields();

  if (settings.backendToken) {
    loadBackendAccountData();
  }

  // Toggle visibility of API key inputs
  document.getElementById('toggle-ghl-key')?.addEventListener('click', () => togglePasswordField('ghl-api-key'));

  // GHL validate
  document.getElementById('btn-validate-ghl')?.addEventListener('click', async () => {
    const apiKey = document.getElementById('ghl-api-key').value.trim();
    const locationId = document.getElementById('ghl-location-id').value.trim();
    const badge = document.getElementById('ghl-status-badge');

    if (!apiKey || !locationId) {
      setStatus(badge, '⚠ Enter both API key and Location ID first.', 'error');
      return;
    }

    setStatus(badge, '<span class="spinner"></span> Testing connection…', 'connected');
    const result = await sendMsg({ action: 'VALIDATE_GHL', apiKey, locationId });

    if (result?.valid) {
      setStatus(badge, `✓ Connected to: ${result.locationName}`, 'connected');
    } else {
      setStatus(badge, `✗ ${result?.error || 'Connection failed'}`, 'error');
    }
  });

  // GHL save
  document.getElementById('btn-save-ghl')?.addEventListener('click', async () => {
    const apiKey = document.getElementById('ghl-api-key').value.trim();
    const locationId = document.getElementById('ghl-location-id').value.trim();
    await sendMsg({ action: 'SAVE_SETTINGS', data: { ghlApiKey: apiKey, ghlLocationId: locationId } });
    settings.ghlApiKey = apiKey;
    settings.ghlLocationId = locationId;
    showSaveToast('GHL settings saved!');
  });

  // Backend save base URL on blur
  document.getElementById('backend-api-base')?.addEventListener('blur', async (e) => {
    const backendApiBase = e.target.value.trim();
    if (!backendApiBase) return;
    await sendMsg({ action: 'SAVE_SETTINGS', data: { backendApiBase, backendEnabled: true } });
    settings.backendApiBase = backendApiBase;
  });

  // Backend register
  document.getElementById('btn-backend-register')?.addEventListener('click', async () => {
    const email = document.getElementById('backend-auth-email').value.trim();
    const password = document.getElementById('backend-auth-password').value;
    const backendApiBase = document.getElementById('backend-api-base').value.trim();
    const badge = document.getElementById('backend-status-badge');

    if (!email || !password || !backendApiBase) {
      setStatus(badge, '⚠ Enter backend URL, email, and password first.', 'error');
      return;
    }

    await sendMsg({ action: 'SAVE_SETTINGS', data: { backendApiBase, backendEnabled: true } });
    settings.backendApiBase = backendApiBase;
    settings.backendEnabled = true;

    setStatus(badge, '<span class="spinner"></span> Registering…', 'connected');
    const result = await sendMsg({ action: 'BACKEND_REGISTER', email, password });
    if (!result?.success) {
      setStatus(badge, `✗ ${result?.error || 'Registration failed'}`, 'error');
      return;
    }

    settings = result.settings || settings;
    updateSidebarPlanInfo();
    refreshPlanLabel();
    await loadBackendAccountData();
    setStatus(badge, `✓ Signed in as ${result.user?.email || email}`, 'connected');
    showSaveToast('Backend account created and connected.');
  });

  // Backend login
  document.getElementById('btn-backend-login')?.addEventListener('click', async () => {
    const email = document.getElementById('backend-auth-email').value.trim();
    const password = document.getElementById('backend-auth-password').value;
    const backendApiBase = document.getElementById('backend-api-base').value.trim();
    const badge = document.getElementById('backend-status-badge');

    if (!email || !password || !backendApiBase) {
      setStatus(badge, '⚠ Enter backend URL, email, and password first.', 'error');
      return;
    }

    await sendMsg({ action: 'SAVE_SETTINGS', data: { backendApiBase, backendEnabled: true } });
    settings.backendApiBase = backendApiBase;
    settings.backendEnabled = true;

    setStatus(badge, '<span class="spinner"></span> Signing in…', 'connected');
    const result = await sendMsg({ action: 'BACKEND_LOGIN', email, password });
    if (!result?.success) {
      setStatus(badge, `✗ ${result?.error || 'Sign in failed'}`, 'error');
      return;
    }

    settings = result.settings || settings;
    updateSidebarPlanInfo();
    refreshPlanLabel();
    await loadBackendAccountData();
    setStatus(badge, `✓ Signed in as ${result.user?.email || email}`, 'connected');
    showSaveToast('Backend sign-in successful.');
  });

  // Backend logout
  document.getElementById('btn-backend-logout')?.addEventListener('click', async () => {
    const badge = document.getElementById('backend-status-badge');
    const result = await sendMsg({ action: 'BACKEND_LOGOUT' });
    if (!result?.success) {
      setStatus(badge, `✗ ${result?.error || 'Sign out failed'}`, 'error');
      return;
    }
    settings = result.settings || settings;
    refreshPlanLabel();
    clearDashboardAccountPanels();
    setStatus(badge, '● Signed out from backend.', 'connected');
    showSaveToast('Signed out.');
  });

  // Backend usage refresh
  document.getElementById('btn-backend-usage')?.addEventListener('click', async () => {
    const badge = document.getElementById('backend-status-badge');
    setStatus(badge, '<span class="spinner"></span> Fetching usage…', 'connected');
    const result = await sendMsg({ action: 'BACKEND_GET_USAGE' });
    if (!result?.success) {
      setStatus(badge, `✗ ${result?.error || 'Unable to fetch usage'}`, 'error');
      return;
    }

    const sr = await sendMsg({ action: 'GET_SETTINGS' });
    settings = sr?.settings || settings;
    updateSidebarPlanInfo();
    refreshPlanLabel();
    const remaining = result.usage?.clonesRemaining;
    setStatus(badge, `✓ Usage synced${remaining >= 0 ? ` · ${remaining} clones remaining` : ' · unlimited'}`, 'connected');
  });

  // Backend funnel sync
  document.getElementById('btn-backend-sync')?.addEventListener('click', async () => {
    const badge = document.getElementById('backend-status-badge');
    setStatus(badge, '<span class="spinner"></span> Syncing funnels…', 'connected');
    const result = await sendMsg({ action: 'BACKEND_SYNC_FUNNELS' });
    if (!result?.success) {
      setStatus(badge, `✗ ${result?.error || 'Funnel sync failed'}`, 'error');
      return;
    }
    setStatus(badge, `✓ Synced ${result.synced || 0} funnel(s)`, 'connected');
  });

  // Stripe checkout buttons
  document.getElementById('btn-upgrade-starter')?.addEventListener('click', async () => {
    await startCheckout('starter');
  });
  document.getElementById('btn-upgrade-pro')?.addEventListener('click', async () => {
    await startCheckout('pro');
  });
  document.getElementById('btn-upgrade-agency')?.addEventListener('click', async () => {
    await startCheckout('agency');
  });

  // Current plan display
  refreshPlanLabel();

  // Reset credits button
  document.getElementById('btn-reset-credits')?.addEventListener('click', async () => {
    await sendMsg({ action: 'SAVE_SETTINGS', data: { credits: 999 } });
    settings.credits = 999;
    refreshPlanLabel();
    updateSidebarPlanInfo();
    showSaveToast('Credits reset to 999!');
  });

}

// ─── My Account Tab ───────────────────────────────────────────────────────────
function setupAccountTab() {
  document.getElementById('btn-refresh-profile')?.addEventListener('click', async () => {
    await loadBackendAccountData(true);
  });

  document.getElementById('btn-save-profile')?.addEventListener('click', async () => {
    const badge = document.getElementById('profile-status-badge');
    if (!requireBackendAuth(badge)) return;

    setStatus(badge, '<span class="spinner"></span> Saving profile…', 'connected');
    const result = await sendMsg({
      action: 'BACKEND_UPDATE_PROFILE',
      displayName: document.getElementById('profile-display-name')?.value?.trim() || '',
      company: document.getElementById('profile-company')?.value?.trim() || '',
      timezone: document.getElementById('profile-timezone')?.value?.trim() || 'UTC',
    });

    if (!result?.success) {
      setStatus(badge, `✗ ${result?.error || 'Unable to save profile'}`, 'error');
      return;
    }

    settings = result.settings || settings;
    populateProfileForm(result.user?.profile || result.profile || null);
    setStatus(badge, '✓ Profile updated.', 'connected');
  });

  document.getElementById('btn-change-password')?.addEventListener('click', async () => {
    const badge = document.getElementById('profile-status-badge');
    if (!requireBackendAuth(badge)) return;

    const currentPassword = document.getElementById('profile-current-password')?.value || '';
    const newPassword = document.getElementById('profile-new-password')?.value || '';
    if (!currentPassword || !newPassword) {
      setStatus(badge, '⚠ Enter current and new password.', 'error');
      return;
    }

    setStatus(badge, '<span class="spinner"></span> Changing password…', 'connected');
    const result = await sendMsg({ action: 'BACKEND_CHANGE_PASSWORD', currentPassword, newPassword });

    if (!result?.success) {
      setStatus(badge, `✗ ${result?.error || 'Unable to change password'}`, 'error');
      return;
    }

    document.getElementById('profile-current-password').value = '';
    document.getElementById('profile-new-password').value = '';
    setStatus(badge, '✓ Password updated.', 'connected');
  });

  document.getElementById('btn-save-preferences')?.addEventListener('click', async () => {
    const badge = document.getElementById('profile-status-badge');
    if (!requireBackendAuth(badge)) return;

    const preferences = {
      theme: document.getElementById('pref-theme')?.value || 'dark',
      defaultNiche: document.getElementById('pref-default-niche')?.value || 'general',
      notifications: Boolean(document.getElementById('pref-notifications')?.checked),
    };

    setStatus(badge, '<span class="spinner"></span> Saving preferences…', 'connected');
    const result = await sendMsg({ action: 'BACKEND_SAVE_PREFERENCES', preferences });

    if (!result?.success) {
      setStatus(badge, `✗ ${result?.error || 'Unable to save preferences'}`, 'error');
      return;
    }

    populatePreferencesForm(result.preferences || preferences);
    setStatus(badge, '✓ Preferences saved.', 'connected');
  });

  document.getElementById('btn-load-analytics')?.addEventListener('click', async () => {
    await loadAnalytics();
  });

  document.getElementById('btn-load-activity')?.addEventListener('click', async () => {
    await loadActivity();
  });
}

function loadSettingsFields() {
  if (settings.ghlApiKey) document.getElementById('ghl-api-key').value = settings.ghlApiKey;
  if (settings.ghlLocationId) document.getElementById('ghl-location-id').value = settings.ghlLocationId;
  if (settings.backendApiBase) document.getElementById('backend-api-base').value = settings.backendApiBase;

  if (settings.ghlApiKey && settings.ghlLocationId) {
    setStatus(document.getElementById('ghl-status-badge'), '● GHL credentials saved. Click "Test Connection" to verify.', 'connected');
  }
  if (settings.backendToken && settings.backendUser?.email) {
    setStatus(document.getElementById('backend-status-badge'), `● Signed in as ${settings.backendUser.email}`, 'connected');
  }
}

function requireBackendAuth(statusEl) {
  if (settings.backendToken) return true;
  if (statusEl) setStatus(statusEl, '⚠ Sign in to cloud backend first.', 'error');
  return false;
}

function populateProfileForm(profile) {
  if (!profile) return;
  document.getElementById('profile-display-name').value = profile.displayName || '';
  document.getElementById('profile-company').value = profile.company || '';
  document.getElementById('profile-timezone').value = profile.timezone || 'UTC';
}

function populatePreferencesForm(preferences) {
  if (!preferences) return;
  document.getElementById('pref-theme').value = preferences.theme || 'dark';
  document.getElementById('pref-default-niche').value = preferences.defaultNiche || 'general';
  document.getElementById('pref-notifications').checked = Boolean(preferences.notifications);
}

async function loadBackendAccountData(showToast = false) {
  const profileBadge = document.getElementById('profile-status-badge');
  const analyticsBadge = document.getElementById('analytics-status-badge');
  if (!requireBackendAuth(profileBadge)) return;

  const me = await sendMsg({ action: 'BACKEND_ME' });
  if (!me?.success) {
    setStatus(profileBadge, `✗ ${me?.error || 'Unable to load account'}`, 'error');
    return;
  }

  settings = me.settings || settings;
  updateSidebarPlanInfo();
  refreshPlanLabel();
  populateProfileForm(me.user?.profile || null);
  populatePreferencesForm(me.preferences || null);
  setStatus(profileBadge, `✓ Profile loaded for ${me.user?.email || 'user'}.`, 'connected');

  // Populate My Account usage overview
  const planEl = document.getElementById('acct-plan-name');
  if (planEl) planEl.textContent = (settings.plan || 'free').charAt(0).toUpperCase() + (settings.plan || 'free').slice(1);
  const usageResult = await sendMsg({ action: 'BACKEND_GET_USAGE' });
  const clEl = document.getElementById('acct-clones-used');
  if (clEl && usageResult?.usage) clEl.textContent = String(usageResult.usage.clonesUsed ?? 0);
  const vidEl = document.getElementById('acct-videos');
  if (vidEl) {
    const jobsResult = await sendMsg({ action: 'BACKEND_VIDEO_LIST_JOBS', limit: 100 });
    const completedCount = (jobsResult?.jobs || []).filter(j => j.status === 'completed').length;
    vidEl.textContent = String(completedCount);
  }

  await loadAnalytics(false);
  await loadActivity(false);

  if (showToast) showSaveToast('Profile refreshed.');
  if (analyticsBadge && analyticsBadge.classList.contains('error')) {
    setStatus(analyticsBadge, '✓ Analytics panel ready.', 'connected');
  }
}

function clearDashboardAccountPanels() {
  document.getElementById('profile-display-name').value = '';
  document.getElementById('profile-company').value = '';
  document.getElementById('profile-timezone').value = 'UTC';
  document.getElementById('profile-current-password').value = '';
  document.getElementById('profile-new-password').value = '';

  document.getElementById('pref-theme').value = 'dark';
  document.getElementById('pref-default-niche').value = 'general';
  document.getElementById('pref-notifications').checked = true;

  ['analytics-total-funnels', 'analytics-clones', 'analytics-optimizations', 'analytics-exports']
    .forEach((id) => { const el = document.getElementById(id); if (el) el.textContent = '-'; });

  const body = document.getElementById('activity-table-body');
  if (body) {
    body.innerHTML = '<tr><td colspan="4" class="activity-empty">Sign in to load activity.</td></tr>';
  }
}

async function loadAnalytics(showStatus = true) {
  const badge = document.getElementById('analytics-status-badge');
  if (!requireBackendAuth(badge)) return;

  if (showStatus) setStatus(badge, '<span class="spinner"></span> Loading analytics…', 'connected');
  const result = await sendMsg({ action: 'BACKEND_GET_ANALYTICS', days: 30 });
  if (!result?.success) {
    setStatus(badge, `✗ ${result?.error || 'Unable to load analytics'}`, 'error');
    return;
  }

  const totals = result.analytics?.totals || {};
  document.getElementById('analytics-total-funnels').textContent = String(totals.totalFunnels ?? 0);
  document.getElementById('analytics-clones').textContent = String(totals.clones ?? 0);
  document.getElementById('analytics-optimizations').textContent = String(totals.aiOptimizations ?? 0);
  document.getElementById('analytics-exports').textContent = String(totals.exports ?? 0);

  if (showStatus) setStatus(badge, '✓ Analytics updated.', 'connected');
}

function formatActivityTime(value) {
  if (!value) return '-';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '-';
  return d.toLocaleString();
}

async function loadActivity(showStatus = true) {
  const badge = document.getElementById('analytics-status-badge');
  const body = document.getElementById('activity-table-body');
  if (!requireBackendAuth(badge)) return;

  if (showStatus) setStatus(badge, '<span class="spinner"></span> Loading activity…', 'connected');
  const result = await sendMsg({ action: 'BACKEND_GET_ACTIVITY', limit: 25, offset: 0 });
  if (!result?.success) {
    setStatus(badge, `✗ ${result?.error || 'Unable to load activity'}`, 'error');
    return;
  }

  const rows = result.activity || [];
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="4" class="activity-empty">No recent activity found.</td></tr>';
  } else {
    body.innerHTML = rows.map((row) => {
      const resource = row.resourceType === 'funnel'
        ? `${row.resourceType}:${row.resourceId || '-'}`
        : (row.resourceType || '-');
      return `
        <tr>
          <td>${escHtml(formatActivityTime(row.createdAt))}</td>
          <td>${escHtml(row.action || '-')}</td>
          <td>${escHtml(resource)}</td>
          <td>${escHtml(row.status || '-')}</td>
        </tr>
      `;
    }).join('');
  }

  if (showStatus) setStatus(badge, `✓ Loaded ${rows.length} activity row(s).`, 'connected');
}

function refreshPlanLabel() {
  const planLabel = document.getElementById('current-plan-label');
  if (!planLabel) return;
  const plan = settings.plan || 'free';
  const planName = plan.charAt(0).toUpperCase() + plan.slice(1);

  if (plan === 'free') {
    const credits = settings.credits ?? 6;
    planLabel.textContent = `Current: ${planName} Plan · ${credits} clone${credits !== 1 ? 's' : ''} remaining`;
  } else if (plan === 'starter') {
    const credits = settings.credits ?? 24;
    planLabel.textContent = `Current: ${planName} Plan · ${credits} clone${credits !== 1 ? 's' : ''} remaining`;
  } else if (plan === 'pro') {
    planLabel.textContent = `Current: ${planName} Plan · 300 clones/month`;
  } else {
    planLabel.textContent = `Current: ${planName} Plan · Unlimited clones`;
  }
}

async function startCheckout(plan) {
  if (!settings.backendApiBase) {
    alert('Checkout is unavailable: set Backend API URL in Settings first.');
    switchTab('settings');
    return;
  }

  if (!settings.backendToken) {
    alert('Checkout requires sign-in. Please sign in under Backend Account in Settings.');
    switchTab('settings');
    return;
  }

  const buttonId = plan === 'agency' ? 'btn-upgrade-agency' : plan === 'starter' ? 'btn-upgrade-starter' : 'btn-upgrade-pro';
  const button = document.getElementById(buttonId);
  const originalHtml = button?.innerHTML;
  if (button) {
    button.disabled = true;
    button.innerHTML = '<span class="spinner"></span> Redirecting…';
  }

  const result = await sendMsg({ action: 'BACKEND_CHECKOUT', plan });
  if (button) {
    button.disabled = false;
    button.innerHTML = originalHtml || button.textContent;
  }

  if (!result?.success) {
    alert(`Checkout failed: ${result?.error || 'Unknown error'}`);
    return;
  }
  if (result.url) {
    chrome.tabs.create({ url: result.url });
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function setToolStatus(el, html, type) {
  if (!el) return;
  el.innerHTML = html;
  el.className = `tool-status ${type}`;
}

function setStatus(el, html, type) {
  if (!el) return;
  el.innerHTML = html;
  el.className = `settings-status ${type}`;
  el.style.display = 'block';
}

function togglePasswordField(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.type = el.type === 'password' ? 'text' : 'password';
}

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function nicheToEmoji(niche) {
  const map = {
    plumber: '🔧', electrician: '⚡', hvac: '❄️', roofing: '🏠', cleaning: '🧹',
    landscaping: '🌱', solar: '☀️', real_estate: '🏡', gym: '💪', dental: '🦷',
    coaching: '🚀', insurance: '🛡️', legal: '⚖️', marketing_agency: '📈',
    weight_loss: '🥗', general: '📄',
  };
  return map[niche] || '📄';
}

function showSaveToast(msg) {
  const t = document.createElement('div');
  t.style.cssText = `position:fixed;bottom:24px;right:24px;background:#10B981;color:white;padding:12px 20px;border-radius:8px;font-size:13px;font-weight:600;z-index:9999;animation:fadeIn .2s;`;
  t.textContent = `✓ ${msg}`;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2500);
}

// Global helper for headline copy buttons
window.copyText = function(btn, text) {
  navigator.clipboard.writeText(text).then(() => {
    btn.textContent = '✓';
    setTimeout(() => btn.textContent = '📋', 1200);
  });
};

// Listen for progress messages from background during GHL push
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === 'GHL_PUSH_PROGRESS') {
    console.log(`GHL Push: ${message.step}/${message.total} — ${message.message}`);
  }
});
